library(testthat)
library(rptha)

test_check('rptha')
